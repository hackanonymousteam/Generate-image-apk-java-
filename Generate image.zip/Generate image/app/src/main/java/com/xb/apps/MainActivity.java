package com.xb.apps;



import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;

public class MainActivity extends Activity {

    private WebView webView;

    public void saveBitmap(View result, String р1) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new AlertDialog.Builder(this)
            .setTitle(R.string.title_alert)
            .setMessage(R.string.guide_gray_filter)
            .setPositiveButton(R.string.box_confirm, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Ação quando o botão "OK" é pressionado (opcional)
                    dialog.dismiss();
                }
            })
            .show();
        

        // Cria um layout principal
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT));

        // Cria um WebView programaticamente
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT));

        setupWebView();

        // Adiciona o WebView ao layout principal
        frameLayout.addView(webView);

        // Cria um botão programaticamente
        Button salvarButton = new Button(this);
        salvarButton.setText(R.string.save_png);
        
        salvarButton.setBackgroundColor(Color.parseColor("#4caf50"));
        salvarButton.setLayoutParams(new FrameLayout.LayoutParams(
                                         ViewGroup.LayoutParams.WRAP_CONTENT,
                                         ViewGroup.LayoutParams.WRAP_CONTENT,
                                         Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));

        // Define o clique do botão para salvar a imagem
        salvarButton.setOnClickListener(new View.OnClickListener() {

               
              
            
            
                public void onClick(View v) {
                   //  Chama a função JavaScript para gerar a imagem
                    
                  webView.loadUrl("javascript:gerarImagem()");
                    
                    
                
                    
                    }
                    
                
            });

        // Adiciona o botão ao layout principal
    //   frameLayout.addView(salvarButton);

        // Define o layout principal da atividade
        setContentView(frameLayout);
    }

    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    // Lógica adicional após a página ser carregada, se necessário
                }
            });

        webView.addJavascriptInterface(new WebViewJavaScriptInterface(this), "AndroidInterface");

        // Carrega o conteúdo HTML
        webView.loadDataWithBaseURL(null, getHtmlContent(), "text/html", "utf-8", null);
    }

    private String getHtmlContent() {
        StringBuilder content = new StringBuilder();
        InputStream inputStream = null;

        try {
            inputStream = getAssets().open("gerar.html");
            java.util.Scanner s = new java.util.Scanner(inputStream).useDelimiter("\\A");
            content.append(s.hasNext() ? s.next() : "");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return content.toString();
    }

    private void salvarImagem(String imageUrl) {
        if (Objects.requireNonNull(this).checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } else {
            new DownloadImageTask().execute(imageUrl);
        }
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... params) {
            String imageUrl = params[0];
            try {
                URL url = new URL(imageUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                return BitmapFactory.decodeStream(input);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

       @Override
        protected void onPostExecute(Bitmap result) {
            if (result != null) {
                saveBitmap(result, "image.png");
            } else {
                Toast.makeText(MainActivity.this, R.string.error_save_image,  Toast.LENGTH_SHORT).show();
            }
        }
    }
    

    private void saveBitmap(Bitmap bitmap, String fileName) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");

        // O diretório de Pictures pode variar dependendo da versão do Android
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        try {
            OutputStream out = getContentResolver().openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);

            // Notifica a galeria sobre a nova imagem
            notifyGallery(uri);
            Toast.makeText(MainActivity.this, R.string.save_imagem, Toast.LENGTH_SHORT).show();
        
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void notifyGallery(Uri uri) {
        // Notifica a galeria sobre a nova imagem
        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
    }

    private class WebViewJavaScriptInterface {
        private Context mContext;

        public WebViewJavaScriptInterface(Context context) {
            mContext = context;
        }

        @JavascriptInterface
        public void imagemGerada(final String imageUrl) {
            // Chama a função para salvar a imagem no Java
            runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        salvarImagem(imageUrl);
                    }
                });
        }

        private void runOnUiThread(Runnable action) {
            new Handler(mContext.getMainLooper()).post(action);
        }
    }
	@Override
	public void onBackPressed() {
		super.onBackPressed();
		finish(); // Isso fechará a atividade atual e voltará para a anterior
	}
	
	
	
}

